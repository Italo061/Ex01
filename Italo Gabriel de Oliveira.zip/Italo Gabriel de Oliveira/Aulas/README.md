# IESB_construcao_backend2


# EXTENSÕES

Tema: COBALT2

- Code Runner
- IntelliCode
- Material Icon Theme
- npm Intellisense
- Path Intellisense
- DotENV
