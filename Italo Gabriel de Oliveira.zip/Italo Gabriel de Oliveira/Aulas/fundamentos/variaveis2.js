// criando variáveis com o const (CONSTANTE -> não pode ser alterado)
const primeiroNome = "Gustavo"
const nomeDoMeio = "Nascimento"
const ultimoNome = "Lima"
// criando variáveis com o let (variavel que pode ser alterada)
let idade = 25

idade = 30

console.log("NOME: ", primeiroNome + " " + nomeDoMeio + " " + ultimoNome)
console.log("IDADE: " + idade)


