// Criando variaveis com var
var nomeCompleto

// atribuição na variavel nomeCompleto (=)
nomeCompleto = "Gustavo Clay"

// console.log("Olá ", nomeCompleto)

var primeiroNome = "Gustavo"
var nomeDoMeio = "Nascimento"
var ultimoNome = "Lima"
var idade = 25

idade = 30

// console.log(primeiroNome, nomeDoMeio, ultimoNome, idade)

console.log("NOME: ", primeiroNome + " " + nomeDoMeio + " " + ultimoNome)
console.log("IDADE: " + idade)


