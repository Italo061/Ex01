// este código é um comentário de uma linha

/*
    este código é um comentário em bloco
*/

var nome = "Gustavo"

// Imprimi no terminal alguma informação
console.log("Olá", nome)